export default function Subscribe() {
    return (
        <div className="subscribe">
            <h3>
                Subscribe! and recieve exclusive news and updates.
            </h3>
            <input type="text" placeholder="Your Name" />
            <input type="text" placeholder="Your Email" />
            <input type="text" placeholder="Your Phone" />
            <button>join our tribe</button>
        </div>
    )
}